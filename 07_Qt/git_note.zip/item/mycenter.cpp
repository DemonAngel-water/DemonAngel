#include "mycenter.h"
#include <QDebug>

mycenter::mycenter(QObject *parent) : QObject(parent)
{
    this->tcp = new QTcpSocket();
    this->login = new my_login();
    this->main_win = new MainWindow();
    connect(this->login, &my_login::send_info_center, this, &mycenter::recv_login);
    connect(this->tcp, &QTcpSocket::readyRead, this, &mycenter::entry_main);
    connect(this->main_win, &MainWindow::pull_file_sig, this, &mycenter::c_pull_file);
    connect(this->main_win, &MainWindow::back_up_file_sig, this, &mycenter::c_back_file);
    this->login->show();
}


void mycenter::recv_login(QString usr, QString pwd)
{
    qDebug() << usr << pwd;
    this->msg = "lgi:" + usr + ":" + pwd;
    this->tcp->connectToHost("192.168.3.12", 8888);
    this->tcp->write(this->msg.toLocal8Bit());
}

void mycenter::entry_main()
{
    this->msg.clear();
    qDebug() << this->msg.append(this->tcp->readAll());
    if(this->msg.endsWith("ok"))
    {
        this->login->close();
        this->main_win->show();
    }
    else if(this->msg.endsWith("read"))
    {
        this->msg.clear();
        this->msg = this->main_win->te->toPlainText();
        this->tcp->write(this->msg.toLocal8Bit());
    }
    else if(!this->msg.contains("ok") && !this->msg.contains("len") && !this->msg.contains("read"))
    {
        this->main_win->te->setText(this->msg);
    }
}


void mycenter::c_pull_file(QString filename)
{
    this->msg.clear();
    this->msg = "pull " + filename;
    this->tcp->write(this->msg.toLocal8Bit());
}


void mycenter::c_back_file(int size, QString filename)
{
    this->msg.clear();
    QString _size = QString::number(size);
    this->msg = _size;
    this->msg = "back " + filename + " " + _size;
    this->tcp->write(this->msg.toLocal8Bit());
}


