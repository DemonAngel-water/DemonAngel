#ifndef MYLOGIN_H
#define MYLOGIN_H

#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QHBoxLayout>
#include <QVBoxLayout>

class my_login : public QDialog
{
    Q_OBJECT
public:
    my_login(QDialog *parent = nullptr);


    QLabel *lb1;
    QLabel *lb2;
    QLabel *lb3;

    QPushButton *but1;
    QPushButton *but2;

    QLineEdit *le1;
    QLineEdit *le2;

    QHBoxLayout *hb1;
    QHBoxLayout *hb2;
    QHBoxLayout *hb3;

    QVBoxLayout *vb;

    void init_login();
signals:
    void send_info_center(QString usr, QString pwd);
private slots:
    void send_info_sig();
};

#endif // MYLOGIN_H
