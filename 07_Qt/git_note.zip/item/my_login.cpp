#include "my_login.h"
#include <QDebug>


my_login::my_login(QDialog *parent) : QDialog(parent)
{
    this->setWindowTitle(tr("git_note"));
    this->setWindowIcon(QIcon(":/src/src/icon.jpg"));
    this->setFixedSize(QSize(320,280));
    init_login();

    connect(this->but1, &QPushButton::clicked, this, &my_login::send_info_sig);
}

void my_login::init_login()
{
    this->lb1 = new QLabel(tr("welcome to git_note"));
    this->lb2 = new QLabel(tr("username:"));
    this->lb3 = new QLabel(tr("password:"));

    this->lb1->setAlignment(Qt::AlignHCenter);
    this->lb1->setFixedHeight(30);

    this->le1 = new QLineEdit();
    this->le1->setPlaceholderText("用户名/密码不能为空");
    this->le2 = new QLineEdit();


#if 0
    this->le1->setText("100001");
    this->le2->setText("t12345");
#endif

    this->le2->setEchoMode(QLineEdit::Password);
    this->but1 = new QPushButton(tr("login"));
    this->but2 = new QPushButton(tr("register"));

    this->hb1 = new QHBoxLayout();
    this->hb2 = new QHBoxLayout();
    this->hb3 = new QHBoxLayout();

    this->vb = new QVBoxLayout();

    this->hb1->addWidget(this->lb2);
    this->hb1->addWidget(this->le1);
    this->hb2->addWidget(this->lb3);
    this->hb2->addWidget(this->le2);

    this->hb3->addWidget(this->but1);
    this->hb3->addWidget(this->but2);

    this->vb->addWidget(this->lb1);

    this->vb->addLayout(this->hb1);
    this->vb->addLayout(this->hb2);
    this->vb->addLayout(this->hb3);

    this->setLayout(this->vb);

}


void my_login::send_info_sig()
{
    qDebug() << this->le1->text() << this->le2->text();
    if(NULL != this->le1->text() && NULL != this->le2->text())
    {
        emit send_info_center(this->le1->text(), this->le2->text());
    }
    else
    {
        if(this->le1->text() != NULL)
        {
            this->le1->setText("");
            this->le1->setPlaceholderText("用户名/密码为空");
        }

    }
}
