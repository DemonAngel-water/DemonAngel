#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QToolBar>
#include <QDockWidget>
#include <QWidget>
#include <QStatusBar>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QTextEdit>
#include <QHBoxLayout>

#include <QFileDialog>
#include <QFontDialog>
#include <QTextCursor>
#include <QColorDialog>


class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
public:
    QMenuBar *mb;
    QMenu *file;
    QMenu *edit;
    QMenu *style;

    QDockWidget *dw;
    QWidget *c_wid;

    QAction *create_file;
    QAction *open_file;
    QAction *save_file;
    QAction *save_as_file;
    QAction *copy_word;
    QAction *paste_word;
    QAction *font_word;
    QAction *color_word;
    QAction *open_project;
    QAction *delete_item;
    QAction *cut_word;
    QAction *undo_word;
    QAction *pull_file;
    QAction *back_up_file;

    QToolBar *tb;

    QStatusBar *sb;

    QTreeWidget *tw;

    QTextEdit *te;
    QHBoxLayout *hb1;
    QTextCursor cur;

    QString file_name;
    QString root_name;



public:
    void init_main();
    void create_file_fun();
    void open_file_fun();
    void save_file_fun();
    void save_as_file_fun();
    void open_project_fun();
    void show_tree_pro(QString path, QTreeWidgetItem *item);
    void word_color();
    void word_font();
    void show_file_test();
    void delete_node();
    void connect_main();
    void cut_fun();
    void copy_fun();
    void undo_fun();
    void paste_fun();
    void zoom_in_fun();
    void zoom_out_fun();

signals:
    void pull_file_sig(QString filename);
    void back_up_file_sig(int size, QString filename);
public slots:
    void pull_file_slo();
    void back_up_file_slo();

};
#endif // MAINWINDOW_H
