#ifndef MYCENTER_H
#define MYCENTER_H

#include <QObject>
#include "my_login.h"
#include "mainwindow.h"
#include <QTcpSocket>

class mycenter : public QObject
{
    Q_OBJECT
public:
    explicit mycenter(QObject *parent = nullptr);

public:
    my_login *login;
    QTcpSocket *tcp;
    QString msg;
    MainWindow *main_win;
signals:
public slots:
    void recv_login(QString usr, QString pwd);
    void entry_main();
    void c_pull_file(QString filename);
    void c_back_file(int size, QString filename);

};

#endif // MYCENTER_H
