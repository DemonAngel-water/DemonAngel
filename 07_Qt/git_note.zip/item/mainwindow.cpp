﻿#include "mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    this->setWindowIcon(QIcon(":/src/src/icon.jpg"));
    this->setMinimumSize(QSize(1024,640));

    init_main();
    connect_main();
}

MainWindow::~MainWindow()
{

}


void MainWindow::connect_main()
{
    connect(this->create_file, &QAction::triggered, this, &MainWindow::create_file_fun);
    connect(this->open_file, &QAction::triggered, this, &MainWindow::open_file_fun);
    connect(this->save_file, &QAction::triggered, this, &MainWindow::save_file_fun);
    connect(this->save_as_file, &QAction::triggered, this, &MainWindow::save_as_file_fun);
    connect(this->open_project, &QAction::triggered, this, &MainWindow::open_project_fun);
    connect(this->font_word, &QAction::triggered, this, &MainWindow::word_font);
    connect(this->color_word, &QAction::triggered, this, &MainWindow::word_color);
    connect(this->tw, &QTreeWidget::itemDoubleClicked, this, &MainWindow::show_file_test);
    connect(this->delete_item, &QAction::triggered, this, &MainWindow::delete_node);
    connect(this->copy_word, &QAction::triggered, this, &MainWindow::copy_fun);
    connect(this->paste_word, &QAction::triggered, this, &MainWindow::paste_fun);
    connect(this->cut_word, &QAction::triggered, this, &MainWindow::cut_fun);
    connect(this->undo_word, &QAction::triggered, this, &MainWindow::undo_fun);
    connect(this->pull_file, &QAction::triggered, this, &MainWindow::pull_file_slo);
    connect(this->back_up_file, &QAction::triggered, this, &MainWindow::back_up_file_slo);

}
void MainWindow::init_main()
{
    this->mb = new QMenuBar();
    this->file = new QMenu(tr("文件"));
    this->edit = new QMenu(tr("编辑"));
    this->style = new QMenu(tr("样式"));

    this->create_file = new QAction(tr("创建"));
    this->create_file->setShortcut(QKeySequence(tr("Ctrl+N")));
    this->open_file = new QAction(tr("打开"));
    this->open_file->setShortcut(QKeySequence(tr("Ctrl+O")));
    this->save_file = new QAction(tr("保存"));
    this->save_file->setShortcut(QKeySequence(tr("Ctrl+S")));
    this->save_as_file = new QAction(tr("另存为"));
    this->save_as_file->setShortcut(QKeySequence(tr("Ctrl+Shift+S")));

    this->copy_word = new QAction(tr("复制"));
    this->copy_word->setShortcut(QKeySequence(tr("Ctrl+C")));
    this->paste_word = new QAction(tr("粘贴"));
    this->paste_word->setShortcut(QKeySequence(tr("Ctrl+V")));
    this->cut_word = new QAction(tr("剪切"));
    this->cut_word->setShortcut(QKeySequence(tr("Ctrl+X")));
    this->undo_word = new QAction(tr("撤销"));
    this->undo_word->setShortcut(QKeySequence(tr("Ctrl+Z")));

    this->font_word = new QAction(tr("字体"));
    this->font_word->setShortcut(QKeySequence(tr("Ctrl+F")));
    this->color_word = new QAction(tr("颜色"));

    this->open_project = new QAction(tr("打开文件夹"));
    this->open_project->setShortcut(QKeySequence(tr("Ctrl+Shift+N")));
    this->delete_item = new QAction(tr("删除子项"));

    this->pull_file = new QAction(tr("下载"));
    this->back_up_file = new QAction(tr("备份"));

    this->file->addAction(this->create_file);
    this->file->addSeparator();
    this->file->addAction(this->open_file);
    this->file->addSeparator();
    this->file->addAction(this->save_file);
    this->file->addSeparator();
    this->file->addAction(this->save_as_file);
    this->file->addSeparator();
    this->file->addAction(this->open_project);
    this->file->addSeparator();
    this->file->addAction(this->pull_file);
    this->file->addSeparator();
    this->file->addAction(this->back_up_file);

    this->edit->addAction(this->copy_word);
    this->edit->addSeparator();
    this->edit->addAction(this->paste_word);
    this->edit->addSeparator();
    this->edit->addAction(this->cut_word);
    this->edit->addSeparator();
    this->edit->addAction(this->undo_word);


    this->style->addAction(this->font_word);
    this->style->addSeparator();
    this->style->addAction(this->color_word);

    this->mb->addMenu(this->file);
    this->mb->addMenu(this->edit);
    this->mb->addMenu(this->style);

    this->setMenuBar(this->mb);

    this->tb = new QToolBar();
    this->tb->addAction(this->create_file);
    this->tb->addAction(this->save_file);
    this->tb->addAction(this->delete_item);
    this->tb->addAction(this->pull_file);
    this->tb->addAction(this->back_up_file);

    this->addToolBar(this->tb);

    this->dw = new QDockWidget(tr("工程"));
    this->addDockWidget(Qt::LeftDockWidgetArea, this->dw);
    this->dw->setMinimumWidth(180);

    this->sb = new QStatusBar();
    this->sb->showMessage(tr("欢迎来到Git note"));
    this->setStatusBar(this->sb);

    this->c_wid = new QWidget();
    this->te = new QTextEdit();
    this->hb1 = new QHBoxLayout();


    this->hb1->addWidget(this->te);
    this->c_wid->setLayout(this->hb1);

    this->setCentralWidget(this->c_wid);

    this->tw = new QTreeWidget();

    this->dw->setWidget(this->tw);
    this->tw->setHeaderLabel("工程文件夹");
}



void MainWindow::create_file_fun()
{
    this->save_file_fun();
    this->te->clear();
}

void MainWindow::open_file_fun()
{
    QString filename = QFileDialog::getOpenFileName(this,tr("选择你想要打开的文件"),tr("./"),\
                                                    tr("文件类型(*.h *.c *.cpp *.py *.sh *.ui *.html *.txt *.java)"));
    qDebug() << filename;
    QFile file(filename);
    this->file_name = filename;

    file.open(QIODevice::ReadOnly);
    if(filename.endsWith(".html"))
    {
        this->te->setHtml(QString(file.readAll()));
    }
    else
    {
        this->te->setText(QString(file.readAll()));
    }
    file.close();
    this->sb->showMessage(tr("已打开"));
}

void MainWindow::save_file_fun()
{
    QString con = this->te->document()->toPlainText();
    qDebug() << con;
    QString filen = QFileDialog::getSaveFileName(this, tr("选择你想要保存的文件"), tr("./"),tr("所有文件(*)"));
    qDebug() << filen;

    QFile file(filen);
    QFileInfo *fi = new QFileInfo(filen);
    if(fi->isFile())
    {
        if(file.open(QIODevice::WriteOnly))
        {
            file.write(con.toUtf8());
            file.close();
        }
    }
    else
    {
        if(file.open(QIODevice::NewOnly | QIODevice::WriteOnly))
        {
            file.write(con.toUtf8());
            file.close();
        }
        else
        {
            qDebug() << "error";
        }
    }
}


void MainWindow::save_as_file_fun()
{
    QString filename = QFileDialog::getSaveFileName(this,tr("选择你想要打开的文件"),tr("./"),\
                                                    tr("文件类型(*.h *.c *.cpp *.py *.sh *.ui *.html *.txt *.java)"));
    QFile file(filename);
    file.open(QIODevice::WriteOnly);
    QTextStream stream(&file);
    stream << this->te->toPlainText();
    this->sb->showMessage(tr("已保存"));
}

void MainWindow::open_project_fun()
{
    QString dir_pro = QFileDialog::getExistingDirectory(this, tr("choose project dir"),tr("./"));
    /* 以/为分隔符将dir_pro分解成小字符串 */

    this->file_name = dir_pro;
    QStringList myl = dir_pro.split("/");
    QTreeWidgetItem *it = new QTreeWidgetItem(this->tw);
    it->setIcon(0, QIcon(":/img/images/dir.jpg"));
    it->setText(0, myl[myl.size() - 1]);
    this->root_name = myl[myl.size() - 1];
    show_tree_pro(dir_pro, it);
}

void MainWindow::show_tree_pro(QString path, QTreeWidgetItem *item)
{
    QDir *my_pro_dir = new QDir(path);
    QFileInfoList myfl = my_pro_dir->entryInfoList();
    for(int i = 0; i < myfl.size(); i++)
    {
        if(myfl[i].fileName() == "." || myfl[i].fileName() == "..")
        {
            continue;
        }
        QTreeWidgetItem *it = new QTreeWidgetItem(item);
        it->setText(0,myfl[i].fileName());
        if(myfl[i].isDir())
        {
            it->setIcon(0,QIcon(":/src/src/Documents.ico"));
            show_tree_pro(myfl[i].filePath(), it);
        }
        else
        {
            if(myfl[i].fileName().endsWith(".h"))
            {
                it->setIcon(0, QIcon(":/src/src/29.ico"));
            }
            else if(myfl[i].fileName().endsWith(".cpp"))
            {
                it->setIcon(0, QIcon(":/src/src/35.ico"));
            }
            else if(myfl[i].fileName().endsWith(".jpg"))
            {
                it->setIcon(0, QIcon(":/src/src/31.ico"));
            }
            else if(myfl[i].fileName().endsWith(".txt"))
            {
                it->setIcon(0, QIcon(":/src/src/29.ico"));
            }
            else
            {
                it->setIcon(0, QIcon(":/src/src/101.bmp"));
            }
        }
    }
}

void MainWindow::word_font()
{
    bool ok; // 用户字体对话框保存是否选择了字体的结构
    QFont f_before;
    QFont f_after = QFontDialog::getFont(&ok,f_before,this,"select font");
    if(ok)
    {
        f_before = f_after;
        this->te->setCurrentFont(f_after);
    }
}

void MainWindow::word_color()
{
    QColor c_before;
    QColor c_after = QColorDialog::getColor(c_before, this, "select color");
    if(c_after.isValid())
    {
        c_before = c_after;
        this->te->setTextColor(c_after);
    }
}

void MainWindow::show_file_test()
{
    QString filename;
    qDebug() << this->tw->currentItem()->text(0);
    while(this->tw->currentItem()->parent()->childCount() > 0 && this->tw->currentItem()->parent()->text(0) != this->root_name)
    {
        filename = this->file_name + "/" + this->tw->currentItem()->parent()->text(0) + "/" + this->tw->currentItem()->text(0);
        break;
    }
    if(0 == this->tw->currentItem()->childCount() && this->tw->currentItem()->parent()->text(0) == this->root_name)
    {
        filename = this->file_name + "/" + this->tw->currentItem()->text(0);
    }
    QFile file(filename);
    file.open(QIODevice::ReadWrite);
    if(filename.endsWith(".html"))
    {
        this->te->setHtml(QString(file.readAll()));
    }
    else
    {
        this->te->setText(QString(file.readAll()));
    }
    file.close();
    this->sb->showMessage("文件已打开");
}

void MainWindow::delete_node()
{
    QTreeWidgetItem *item = this->tw->currentItem();
    QTreeWidgetItem *parent = item->parent();

    parent->removeChild(item);
    delete item;
}

void MainWindow::cut_fun()
{
    this->te->cut();
}

void MainWindow::undo_fun()
{
    this->te->undo();
}

void MainWindow::copy_fun()
{
    this->te->copy();
}

void MainWindow::paste_fun()
{
    this->te->paste();
}


void MainWindow::pull_file_slo()
{
    qDebug() << "下载";
    emit pull_file_sig(this->te->toPlainText());
}

void MainWindow::back_up_file_slo()
{
    qDebug() << "backup";

    emit back_up_file_sig(this->te->toPlainText().size(), this->tw->currentItem()->text(0));
    qDebug() << "size" << this->te->toPlainText().size();
    qDebug() << "filename" << this->tw->currentItem()->text(0);
}

