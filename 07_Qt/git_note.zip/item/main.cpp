#include "mainwindow.h"
#include <QApplication>
#include "mycenter.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    mycenter w;

    return a.exec();
}
