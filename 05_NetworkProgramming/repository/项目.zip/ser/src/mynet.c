#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

//函数功能：初始化服务器
//参数：端口号
//返回值：监听套接字
int init_ser(unsigned short port)
{
    if (port == 0)
    {
        puts("port error.");
        return -1;
    }
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0)
    {
        puts("socket error.");
        return listenfd;
    }
    puts("socket sucess.");

    struct sockaddr_in myser;
    memset(&myser, 0, sizeof(myser));
    myser.sin_family = AF_INET;
    myser.sin_port = htons(port);
    myser.sin_addr.s_addr = htonl(INADDR_ANY);

    int ret = bind(listenfd, (struct sockaddr *)&myser, sizeof(myser));
    if (ret != 0)
    {
        puts("bind error.");
        close(listenfd);
        return -1;
    }
    puts("bind success.");

    ret = listen(listenfd, 5);
    if (ret != 0)
    {
        puts("listen error.");
        close(listenfd);
        return -1;
    }
    puts("listen success.");
    return listenfd;
}
//函数功能：接收客户端
//参数：通信套接字
//返回值：通信套接字
int accept_cli(int listenfd)
{
    if (listenfd < 0)
    {
        puts("accept error.");
        return -1;
    }
    int connfd = -1;
    struct sockaddr_in mycli;
    int len = sizeof(mycli);
    connfd = accept(listenfd, (struct sockaddr *)&mycli, &len);
    if (connfd < 0)
    {
        puts("accept error.");
        return -1;
    }
    puts("accept success.");
    printf("client ip:%s\tport:%d\n", inet_ntoa(mycli.sin_addr), ntohs(mycli.sin_port));
    return connfd;
}
