#include "../include/mynet.h"
#include "../include/sqlite3.h"
#include "../include/myopt.h"
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int do_work(int connfd);

sqlite3 *pdb = NULL;

int main()
{
    //init_sqlite
    sqlite3_open("./bin/mychat.db", &pdb);
    if (NULL == pdb)
    {
        puts("sqlite3_open error.");
        return -1;
    }
    puts("sqlite3_open success.");
    //init_net
    int listenfd = init_ser(8888);
    if (listenfd < 0)
    {
        puts("init ser error.");
        return -1;
    }
	/* 使用select并发服务器 */

	/* 获得listenfd文件描述符的状态 */
	int flag = fcntl(listenfd, F_GETFL);
	/* 设置listenfd文件描述的状态，非阻塞 */
	fcntl(listenfd, F_SETFL, flag | O_NONBLOCK);
	puts("init ser success.");

	/* 定义两个文件描述的集合 */
	fd_set readfds, tempfds;

	/* 清空文件描述符的集合 */
	FD_ZERO(&readfds);
	FD_ZERO(&tempfds);

	/* 将listenfd加入到文件描述符的集合 */
	FD_SET(listenfd, &readfds);
    while (1)
    {
        tempfds = readfds;
        int ret = select(FD_SETSIZE, &tempfds, NULL, NULL, NULL);
        if (ret > 0)
        {
			int i = 0;
			for (i = 3; i < FD_SETSIZE; i++)
			{
				/* 判断文件描述符监听后是不是在这个集合里 */
				if (FD_ISSET(i, &tempfds))
				{
					/* 说明监听套接字可读，即有客户端连接服务器 */
					if (i == listenfd)
					{
						int connfd = accept_cli(i);
						if (connfd > 0)
						{
							/* 获得connfd文件描述符的状态 */
							flag = fcntl(connfd, F_GETFL);
							/* 设置connfd文件描述的状态，非阻塞 */
							fcntl(connfd, F_SETFL, flag | O_NONBLOCK);
							/* 将connfd加入到文件描述符的集合 */
							FD_SET(connfd, &readfds);
						}
                    }
                    else
                    {
                        //do work
                        ret = do_work(i);
                        if (ret == -1)
                        {
                            FD_CLR(i, &readfds);
                            close(i);
                        }
                    }
                }
            }
        }
    }
    close(listenfd);
    sqlite3_close(pdb);
    return 0;
}