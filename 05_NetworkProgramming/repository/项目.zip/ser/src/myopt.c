#include "../include/sqlite3.h"
#include "../include/myopt.h"
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

extern sqlite3 *pdb;
int j = 0;

//函数功能：显示所有字段的内容
static int callback(void *data, int argc, char **argv, char **cloname)
{
    printf("argc:%d\n", argc);
    int i = 0;
    for (i = 0; i < argc; i++)
    {
        printf("%s:%s\n", cloname[i], argv[i]);
    }
    return 0;
}

static int callback_check(void *data, int argc, char **argv, char **cloname)
{
    /* exec传进来的倒数第二个参数的返回值是回调函数的第一个参数data */
    char str[100] = {0};
    printf("argc:%d\n", argc);
    int i = 0;
    for (i = 0; i < argc; i++)
    {
        printf("%s:%s\n", cloname[i], argv[i]);
    }
    strcpy(str, argv[0]);
    strcat(str, ":");
    strcat(str, argv[1]);
    strcat(str, "\n");
    puts(str);
    strcat(data, str);
    puts(data);

    return 0;
}

static int get_passwd(void *data, int argc, char **argv, char **cloname)
{
    int i = 0;
    for (i = 0; i < argc; i++)
    {
        strcpy(data, argv[i]);
    }
}

//函数功能：处理客户端登录请求
//参数:用户id， 用户密码
//返回值:无
int login_usr(char *uid, char *upasswd)
{
    if (NULL == uid || NULL == upasswd)
    {
        return -1;
    }
    char sql[100];
    sprintf(sql, "select upasswd from usr_info where uid = '%s'", uid);
    puts(sql);
    char upsd[7] = {0};
    sqlite3_exec(pdb, sql, get_passwd, upsd, NULL);
    if (strcmp(upsd, upasswd) == 0)
    {
        puts("passwd ok");
        return 1;
    }
    return 0;
}

//函数功能：处理客户端注册请求
//参数：用户名 用户密码
//返回值：
int reg_usr(char *uname, char *upasswd)
{
    if (NULL == uname || NULL == upasswd)
    {
        return -1;
    }
    // insert info into table usr info
    char *perr = NULL;
    char select_sql[] = "select *from usr_info";
    char sql[100];
    sprintf(sql, "insert into usr_info (uname, upasswd) values ('%s', '%s')", uname, upasswd);
    puts(sql);
    sqlite3_exec(pdb, sql, NULL, NULL, &perr);
    if (perr)
    {
        puts(perr);
        sqlite3_close(pdb);
        return -1;
    }
    puts("insert success.");
    // select this usr info
    sqlite3_exec(pdb, select_sql, callback, NULL, &perr);
    if (perr)
    {
        puts(perr);
        sqlite3_close(pdb);
        return -1;
    }
    return 0;
}

//函数功能：处理客户端注销请求
int del_usr(char *uid, char *upasswd)
{
    if (NULL == uid || NULL == upasswd)
    {
        return -1;
    }
    char sql[100];
    sprintf(sql, "delete from usr_info where uid = '%s'", uid);
    puts(sql);
    sqlite3_exec(pdb, sql, NULL, NULL, NULL);
    puts("delete success.");
    return 0;
}

/* 服务器处理私聊请求 */
void send_private_msg(char *username, char *data, int sfd)
{
    printf("进入了私聊函数\n");
    int i, j;
    char send_man[20];
    char buf[BUFFSIZE], temp[30];
    for (j = 0; j < MAXMEM; j++)
    {
        printf("sfd = %d\n", sfd);
        printf("j = %d\n", j);
        printf("online_users[j].socketfd = %d\n", online_users[j].socketfd);
        if (sfd == online_users[j].socketfd)
        {
            printf("j = %d\n", j);
            strcpy(send_man, online_users[j].username);
            printf("当前的发送者是:  %s\n", online_users[j].username);
            break;
        }
    }
    for (i = 0; i < MAXMEM; i++)
    {
        if (strcmp(username, online_users[i].username) == 0)
        {
            printf("当前的的接收者是： %s\n", online_users[i].username);
            memset(buf, 0, sizeof(buf));
            sprintf(buf, "from %s %s\n", send_man, data);
            printf("准备给对方发送的内容是:  %s\n", buf);
            send(online_users[i].socketfd, buf, strlen(buf) + 1, 0);
            strcpy(temp, "send_ok\n");
            printf("给发送消息的客户端回的消息是:  %s\n", temp);
            send(sfd, temp, sizeof(temp), 0);
            return;
        }
    }
    strcpy(buf, "User is not online or user does not exist.\n");
    send(online_users[sfd].socketfd, temp, sizeof(temp), 0);
}
/* 服务器处理群聊请求 */
void send_all_msg(char *msg, int sfd)
{
    printf("进入了群聊函数\n");
    int i;
    char buf[BUFFSIZE], send_man[20], temp[30];
    for (i = 0; i < MAXMEM; i++)
    {
        if (sfd == online_users[i].socketfd)
        {
            printf("i = %d\n", i);
            printf("sfd = %d\n", sfd);
            printf("当前的发送者是:  %s\n", online_users[i].username);
            strcpy(send_man, online_users[i].username);
            break;
        }
    }
    strcpy(buf, "from ");
    strcat(buf, send_man);
    strcat(buf, "(group-send):");
    strcat(buf, msg);
    strcat(buf, "\n");
    for (i = 0; i < MAXMEM; i++)
    {
        if (online_users[i].socketfd && i != sfd)
        {
            printf("准备给所有用户发送的内容是:  %s\n", buf);
            send(online_users[i].socketfd, buf, strlen(buf) + 1, 0);
        }
    }
    strcpy(temp, "send_all ok\n");
    send(online_users[sfd].socketfd, buf, sizeof(buf), 0);
}

//函数功能：服务器处理来自客户端的请求
int do_work(int connfd) //服务器的主函数
{
    if (connfd < 0)
    {
        puts("connfd < 0");
        return -1;
    }
    char cmd[50] = {0};
    char uid[7] = {0};
    char uname[7] = {0};
    char upasswd[7] = {0};
    char shell[50];
    char arg1[50];
    char arg2[50];
    int ret = recv(connfd, cmd, sizeof(cmd), 0);
    if (ret == 0)
    {
        puts("cli is closed");
        return -1;
    }
    else if (ret > 0)
    {
        /* 打印从客户端输入的信息 */
        printf("%d:客户端发来的的消息是\t", connfd);
        puts(cmd);
        /* 处理客户端的登录请求 */
        if (strstr(cmd, "lgi"))
        {
            memset(shell, 0, sizeof(shell));
            memset(uid, 0, sizeof(uid));
            memset(upasswd, 0, sizeof(upasswd));
            /* 解析协议 */
            sscanf(cmd, "%s %s %[^\n]", shell, uid, upasswd);
            printf("shell:%s\tuid:%s\tupasswd:%s\n", shell, uid, upasswd);
            ret = login_usr(uid, upasswd);
            memset(cmd, 0, sizeof(cmd));
            if (ret == 1)
            {
                strcpy(cmd, "lgi_ok");
            }
            else
            {
                strcpy(cmd, "lgi_er");
            }
            strcpy(online_users[j].username, uid);
            online_users[j].status = 0;
            online_users[j].socketfd = connfd;
            printf("j = %d\n", j);
            printf("当前登录的用户通信套接字为: %d\n", connfd);
            j += 1;
            send(connfd, cmd, sizeof(cmd), 0);
        }
        /* 注册 */
        else if (strstr(cmd, "reg"))
        {
            char upassword[7] = {0};
            memset(shell, 0, sizeof(shell));
            memset(uid, 0, sizeof(uid));
            memset(upasswd, 0, sizeof(upasswd));

            sscanf(cmd, "%s %s %s %[^\n]", shell, uname, upasswd, upassword);
            printf("shell:%s\tuname:%s\tupasswd:%s\tupassword:%s\n", shell, uname, upasswd, upassword);
            if (0 == strcmp(upasswd, upassword))
            {
                ret = reg_usr(uname, upasswd);
                memset(cmd, 0, sizeof(cmd));
                if (0 == ret)
                {
                    strcpy(cmd, "reg_ok");
                }
                else
                {
                    strcpy(cmd, "reg_er");
                    printf("password verification error\n");
                }
            }
            else
            {
                strcpy(cmd, "reg_er");
            }
            strcpy(users[user_count].username, uname);
            strcpy(users[user_count].password, upasswd);
            user_count += 1;
            /* send message to cli */
            send(connfd, cmd, sizeof(cmd), 0);
        }
        /* 注销 */
        else if (strstr(cmd, "rle"))
        {
            strncpy(uid, cmd + 4, 6);
            strncpy(upasswd, cmd + 11, 6);
            puts(uid);
            puts(upasswd);

            ret = del_usr(uid, upasswd);
            memset(cmd, 0, sizeof(cmd));
            if (0 == ret)
            {
                strcpy(cmd, "del_ok");
            }
            else
            {
                strcpy(cmd, "del_er");
            }
            send(connfd, cmd, sizeof(cmd), 0);
        }
        /* 查看好友 */
        else if (strstr(cmd, "check"))
        {
            char *perr = NULL;
            printf("客户端发来的查看好友的消息是\n");
            puts(cmd);
            char check_sql[] = "select *from usr_info";
            puts(check_sql);
            char str1[200] = {0};
            sqlite3_exec(pdb, check_sql, callback_check, str1, &perr);
            puts(str1);
            if (perr)
            {
                puts(perr);
                sqlite3_close(pdb);
                return -1;
            }
            puts("check success.");
            char cmd[100] = {0};
            strcpy(cmd, "check_ok");
            send(connfd, str1, sizeof(cmd), 0);
        }
        /* 服务器处理客户端上传文件 */
        else if (strstr(cmd, "push"))
        {
            puts("====================client is pushing====================");
            char shell[5] = {0};
            char filename[30] = {0};
            char f_size[20] = {0};
            sscanf(cmd, "%s %s %[^\n]", shell, filename, f_size);
            printf("shell:%s\tfilename:%s\tfilesize:%s\n", shell, filename, f_size);
            int fd = -1;
            int fl = atoi(f_size);
            printf("fl = %d\n", fl);
            char cmd[100] = {0};
            strcpy(cmd, "push_ok");
            send(connfd, cmd, sizeof(cmd), 0);
            /* 需要客户端在接收之后将文本内容写入并传过来 */
            char *p = (char *)malloc(fl); /* p是文件的大小 */
            fd = open(filename, O_CREAT | O_WRONLY, 0664);
            int total = fl;
            printf("total = %d\n", total);
            while (1)
            {
                if (total <= 0)
                {
                    break;
                }
                /* 接收数据 */
                ret = recv(connfd, p, total, 0);
                if (ret > 0)
                {
                    /* 写入到文件中 */
                    write(fd, p, ret);
                    total -= ret;
                }
            }
            close(fd);
            free(p);
        }
        /* 处理客户端下载文件 */
        else if (strstr(cmd, "pull"))
        {
            puts("====================client is pulling====================");
            memset(shell, 0, sizeof(shell));
            char filename[30] = {0};
            sscanf(cmd, "%s %[^\n]", shell, filename);
            printf("shell:%s\tfilename:%s\n", shell, filename);
            puts(cmd);
            int fd = -1;
            fd = open(filename, O_RDONLY, 0664);
            if (fd < 0)
            {
                puts("fail to open");
                return -1;
            }
            /* 使用lseek定位到文件末尾（文件大小） */
            int f_len = lseek(fd, 0, SEEK_END);
            char f_size[20] = {0};
            sprintf(f_size, "len:%d", f_len);
            /* 将文件大小传给客户端 */
            printf("需要传过去的文件大小是:%s\n", f_size);
            send(connfd, f_size, 20, 0);
            /* 重新定位到文件开头 */
            lseek(fd, 0, SEEK_SET);
            /* malloc一片空间 */
            char *p = (char *)malloc(f_len);
            memset(p, 0, f_len);
            /* 读取内容 */
            ret = read(fd, p, f_len);
            if (ret == f_len)
            {
                puts("开始向客户端发送文件.....");
                /* 将读取的内容发送到客户端 */
                send(connfd, p, f_len, 0);
            }
            free(p);
            close(fd);
        }
        /* 处理客户端发来的聊天消息 */
        else if (strstr(cmd, "send"))
        {
            /* 解析命令 */
            sscanf(cmd, "%s %s %[^\n]", shell, arg1, arg2);
            printf("shell = %s\targ1 = %s\targ2 = %s\n", shell, arg1, arg2);
            /* 根据解析出的命令执行不同的函数 */
            if (strcmp(shell, "send") == 0 && strcmp(arg1, "-all") == 0)
            {
                printf("开始执行群发\n");
                send_all_msg(arg2, connfd);
            }
            else if (strcmp(shell, "send") == 0)
            {
                printf("开始执行私聊\n");
                send_private_msg(arg1, arg2, connfd);
            }
        }
    }
    return 0;
}