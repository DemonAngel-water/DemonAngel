#ifndef _MYNET_H_
#define _MYNET_H_
int init_ser(unsigned short port);
int accept_cli(int listenfd);
#endif