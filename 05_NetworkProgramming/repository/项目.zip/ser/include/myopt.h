#ifndef _MYOPT_H_
#define _MYOPT_H_

#define MAXMEM 20
#define BUFFSIZE 256
int user_count; //记录总的用户数
int listenfd, connfd[MAXMEM];

/*存储用户*/
struct user
{
    char username[20];
    char password[20];
};
struct user users[MAXMEM]; //记录所有用户

/*存储用户及其用户套接字文件描述符*/
struct user_socket
{
    char username[20];
    int socketfd;
    int status; //标识是否在线 0:在线 -1:下线
};
struct user_socket online_users[MAXMEM]; //记录在线用户

struct user_socket online_users[MAXMEM];
int login_usr(char *uid, char *upasswd);
int reg_usr(char *uname, char *upasswd);
int del_usr(char *uid, char *upasswd);
int do_work(int connfd);
void send_private_msg(char *username, char *data, int sfd);
void send_all_msg(char *msg, int sfd);
#endif