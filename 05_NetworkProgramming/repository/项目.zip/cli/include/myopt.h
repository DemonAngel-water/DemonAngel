#ifndef _MYOPT_H_
#define _MYOPT_H_
int do_work(int connfd);
int printf_menu(int lev);
int do_login(int connfd);
int do_register(int connfd);
int do_destroy_usr(int connfd);
int do_upload(char * cmd, int connfd);
int do_download(char * cmd, int connfd);
void snd();
#endif