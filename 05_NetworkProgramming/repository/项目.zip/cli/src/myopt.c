#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../include/myopt.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>

pthread_t thread;
int FLAG;

int do_work(int connfd)
{
    if (connfd < 0)
    {
        return -1;
    }
    /* 客户端登录、注册、注销、上传文件、下载文件 */
    while (1)
    {
        printf_menu(0);
        char cmd[10];
        int login_stat = -1;
        int reg_stat = -1;
        int del_stat = -1;
        fgets(cmd, 10, stdin);
        printf("cmd:%s\n", cmd);
        int c = atoi(cmd);
        switch (c)
        {
        case 1:
            login_stat = do_login(connfd);
            break;
        case 2:
            reg_stat = do_register(connfd);
            break;
        case 3:
            del_stat = do_destroy_usr(connfd);
            break;
        case 4:
            return 0;
        default:
            puts("cannot support this options");
        }
        if (1 == login_stat)
        {
            puts("login success.");
            login_stat = 0;
            break;
        }
        else if (2 == login_stat)
        {
            puts("login error");
            continue;
        }
        if (1 == reg_stat)
        {
            puts("reg success.");
            reg_stat = 0;
        }
        else if (2 == reg_stat)
        {
            puts("reg error");
            continue;
        }
        if (1 == del_stat)
        {
            puts("del success.");
            del_stat = 0;
        }
        else if (2 == del_stat)
        {
            puts("del error");
            continue;
        }
    }
    /* 客户端上传(push)下载(pull)文件 */

    while (1)
    {
        int menu_ret = printf_menu(3);
        if (2 == menu_ret)
        {
            while (1)
            {
                printf_menu(1);
                int op = 0;
                char buf[50];
                memset(buf, 0, sizeof(buf));
                printf("please input your command\n");
                fgets(buf, sizeof(buf), stdin);
                printf("您输入的命令为:");
                puts(buf);
                //下载文件
                if (strstr(buf, "pull"))
                {
                    // do_upload(buf, connfd);
                    printf("进入下载文件的函数\n");
                    printf("sizeof(buf) = %ld\n", sizeof(buf));
                    printf("buf = %s\n", buf);
                    send(connfd, buf, strlen(buf) + 1, 0);
                    char shell[5] = {0};
                    char filename[30] = {0};
                    sscanf(buf, "%s %[^\n]", shell, filename);
                    char f_size[40] = {0};
                    int ret = recv(connfd, f_size, 40, 0);
                    if (ret > 0)
                    {
                        int fl = atoi(f_size + 4);
                        printf("%s size is %d\n", filename, fl);
                        char *p = (char *)malloc(fl);
                        int fd = open(filename, O_CREAT | O_WRONLY, 0664);
                        if (fd < 0)
                        {
                            puts("fail to create");
                        }
                        printf("fd = %d\n", fd);
                        int total = fl;
                        printf("total = %d\n", total);
                        if (total <= 0)
                        {
                            printf("服务器下该文件大小为%d\n", total);
                        }
                        // 接收文件内容
                        ret = recv(connfd, p, total, 0);
                        if (ret > 0)
                        {
                            // 写入到文件中
                            write(fd, p, ret);
                            total -= ret;
                            puts("write success");
                        }
                        printf("pull is ok\n");
                        close(fd);
                        free(p);
                    }
                }
                //上传文件  //需要文件大小传给服务器
                if (strstr(buf, "push"))
                {
                    printf("进入上传文件的函数\n");
                    char shell[5] = {0};
                    char filename[30] = {0};
                    sscanf(buf, "%s %[^\n]", shell, filename);
                    printf("shell:%s\tfilename:%s\n", shell, filename);
                    int fd = -1;
                    fd = open(filename, O_RDONLY, 0664);
                    if (fd < 0)
                    {
                        puts("fail to open");
                        return -1;
                    }
                    printf("fd = %d\n", fd);
                    // 使用lseek定位到文件末尾（文件大小）
                    int f_len = lseek(fd, 0, SEEK_END);
                    // char f_size[20] = {0};
                    // sprintf(f_size, "len:%d", f_len);
                    //  将文件大小传给客户端
                    printf("需要传过去的文件大小是:%d\n", f_len);
                    memset(buf, 0, sizeof(buf));
                    sprintf(buf, "push %s %d", filename, f_len);
                    send(connfd, buf, sizeof(buf), 0);
                    memset(buf, 0, sizeof(buf));
                    int ret = recv(connfd, buf, sizeof(buf), 0);
                    if (ret > 0)
                    {
                        puts(buf);
                    }
                    // 重新定位到文件开头
                    lseek(fd, 0, SEEK_SET);
                    // malloc一片空间
                    char *p = (char *)malloc(f_len);
                    memset(p, 0, f_len);
                    // 读取内容
                    ret = read(fd, p, f_len);
                    if (ret == f_len)
                    {
                        puts("开始向客户端发送文件.....");
                        // 将读取的内容发送到客户端
                        send(connfd, p, f_len, 0);
                    }
                    free(p);
                    close(fd);
                }
                if (strstr(buf, "exit"))
                {
                    break;
                }
            }
        }
        else if (1 == menu_ret)
        {
            /* 客户端开始执行聊天 */
            printf_menu(2);
            char cmd[50];
            memset(cmd, 0, sizeof(cmd));
            /* 1、创建一个线程，执行发送 */
            pthread_create(&thread, NULL, (void *)(&snd), NULL);
            /* 2、继续执行接收 */
            while (1)
            {
                memset(cmd, 0, sizeof(cmd));
                int ret = recv(connfd, cmd, sizeof(cmd), 0);
                if (ret > 0)
                {
                    puts(cmd);
                }
                if (strstr(cmd, "bye"))
                {
                    continue;
                }
            }
        }
        else if (3 == menu_ret)
        {
            return 0;
        }
    }
    return 0;
}

void snd()
{
    char cmd[50];
    while (1)
    {
        memset(cmd, 0, sizeof(cmd));
        fgets(cmd, sizeof(cmd), stdin);
        cmd[strlen(cmd) - 1] = 0;
        if (strcmp(cmd, "\n") != 0)
        {
            printf("您发送的消息是:%s\n", cmd);
            int ret = send(FLAG, cmd, sizeof(cmd), 0);
            printf("send connfd = %d\n", FLAG);
            printf("send ret = %d\n", ret); // ret = -1
        }
        if (strcmp(cmd, "quit\n") == 0)
        {
            exit(0);
        }
        if (strstr(cmd, "bye"))
        {
            break;
        }
    }
}

int printf_menu(int lev)
{
    if (lev < 0)
    {
        return -1;
    }
    if (0 == lev)
    {
        puts("==========================");
        puts("1:login");
        puts("2:register");
        puts("3:destory usr");
        puts("4:quit client");
        puts("==========================");
    }
    else if (1 == lev)
    {
        puts("");
        puts("==========================");
        puts("push file");
        puts("pull file");
        puts("exit files transfer");
        puts("==========================");
    }
    else if (2 == lev)
    {
        puts("");
        puts("==========================");
        puts("send usr msg");
        puts("send -all msg");
        puts("bye");
        puts("==========================");
    }
    else if (3 == lev)
    {

        puts("");
        puts("==========================");
        puts("1.chat");
        puts("2.file");
        puts("3.quit");
        puts("==========================");
        int chat_file = -1;
        scanf("%d", &chat_file);
        getchar();
        if (1 == chat_file)
        {
            return 1;
        }
        else if (2 == chat_file)
        {
            return 2;
        }
        else if (3 == chat_file)
        {
            return 3;
        }
    }
    return 0;
}

int do_login(int connfd)
{
    if (connfd < 0)
    {
        return -1;
    }
    /* 给服务器发送用户id、密码 */
    puts("please input login message:lgi uid passwd");
    char cmd[50];
    memset(cmd, 0, sizeof(cmd));
    fgets(cmd, sizeof(cmd), stdin);
    cmd[strlen(cmd) - 1] = 0;
    int ret = send(connfd, cmd, sizeof(cmd), 0);
    printf("login connnfd = %d\n", connfd);
    FLAG = connfd;
    printf("login ret = %d\n", ret); // ret = 50
    /* 接收服务器返回的消息 */
    memset(cmd, 0, sizeof(cmd));
    ret = recv(connfd, cmd, sizeof(cmd), 0);
    if (ret > 0)
    {
        if (strstr(cmd, "lgi_ok"))
        {
            return 1;
        }
        else
        {
            return 2;
        }
    }
    return 0;
}

int do_register(int connfd)
{
    if (connfd < 0)
    {
        return -1;
    }
    puts("input register message:reg uname passwd again_passwd");
    char cmd[50];
    memset(cmd, 0, sizeof(cmd));
    fgets(cmd, sizeof(cmd), stdin);
    cmd[strlen(cmd) - 1] = 0;
    send(connfd, cmd, sizeof(cmd), 0);
    int ret = -1;
    memset(cmd, 0, sizeof(cmd));
    ret = recv(connfd, cmd, sizeof(cmd), 0);
    if (ret > 0)
    {
        if (strstr(cmd, "reg_ok"))
        {
            return 1;
        }
        else
        {
            return 2;
        }
    }
    return 0;
}

int do_destroy_usr(int connfd)
{
    if (connfd < 0)
    {
        return -1;
    }
    puts("input destroy usr message:rle uid passwd");
    char cmd[50];
    memset(cmd, 0, sizeof(cmd));
    fgets(cmd, sizeof(cmd), stdin);
    cmd[strlen(cmd) - 1] = 0;
    send(connfd, cmd, sizeof(cmd), 0);
    int ret = -1;
    memset(cmd, 0, sizeof(cmd));
    ret = recv(connfd, cmd, sizeof(cmd), 0);
    if (ret > 0)
    {
        if (strstr(cmd, "del_ok"))
        {
            return 1;
        }
        else
        {
            return 2;
        }
    }
    return 0;
}
