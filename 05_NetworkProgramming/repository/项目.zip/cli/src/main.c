#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include "../include/myopt.h"

int main(int argc, char const *argv[])
{
    //socket
    int connfd = socket(AF_INET, SOCK_STREAM, 0);
    if(connfd < 0)
    {
        puts("socket error.");
        return -1;
    }
    puts("socket sucess.");
    //connect
    struct sockaddr_in myser;
    memset(&myser, 0, sizeof(myser));
    myser.sin_family = AF_INET;
    myser.sin_port = htons(8888);
    myser.sin_addr.s_addr = inet_addr("127.0.0.1");
    int ret = connect(connfd, (struct sockaddr *)&myser, sizeof(myser));
    if(ret != 0)
    {
        puts("connnect ser error.");
        close(connfd);
        return -1;
    }
    puts("connect ser success.");
    //do_work
    do_work(connfd);
    //close
    close(connfd);
    return 0;
}
